Sheep-Wolf-Game
This project is P2E Game for NFT minting, Staking of upgrading Sheep v1

Sheep Coin is https://etherscan.io/token/0xe715DbC8c94a6E75fb0914b4dCB80Cd5C4C108Da (2023-5-31)

ENV
node version: v 16.20.0
solidity version: v0.8.0 in remix
Todo list Q3

Deploy new Contracts in the Polygon
Update frontend and web3 for new contracts
Snapshot of Sheep NFT holder
DAO
Q4

develop P2E game (sheepcraft similar to Minecraft)
wolf coin (ERC20)
airdrop wolf coin to sheep NFT holder
genesis pass for sheep vw wolf community